# taxi-locater
a web app similar to mobile apps like ola ,uber etc.
## About
it wokrs similar to apps like ola,uber which finds all taxis available nearby to user and show their location on google maps.taxis shown are only those in whichdriver is currently logged in.
no need to have an app and can be used from any device browser.
## Testing:
download whole source code and host it on any XAMPP or any other localserver.

import the sample database ->database.sql

make respective changes in connectdatabase.php

add your google API key in user.php and driver.php.

now run index.php on local sever and book your cab.
