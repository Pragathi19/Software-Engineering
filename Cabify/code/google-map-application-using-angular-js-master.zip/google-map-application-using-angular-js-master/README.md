# google-map-application-using-angular-js
it is  an angular js based project that is similar to the concept used in taxis and cabs services,or in some games..locations of the user can be updated or of the places

download all the files and run index.html....enjy the app
